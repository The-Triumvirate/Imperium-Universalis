####
# GODS & SPLENDOR Submod
#	More religion flavour in Imperium Universalis
#	by Mrkcosta (@ Discord)
####

# HOW TO INSTALL: copy the descriptor.mod into your mod folder, change the folder path (C:/Users/etc) to match this new folder. Then toggle on in Launcher

# This submod is a PROTOTYPE of some additions I was planning to add into Imperium Universalis. 

# The main goal is to give more content to the existing religions, and doing it by:
	
	- Granting a specific temple for EVERY god/deity in the game, with 4 levels for each, plus other hidden features
	
	- Use Splendor as a RELIGIOUS CURRENCY to spend. For example, its possible uses could be channeled through sacrifices:
		- Store money inside temples will passively create splendor (this money can be looted at sieges)
		- Reclaim money stored in temples in times of need, against the wrath of the gods
		- Spend splendor at the Oracle in exchange of some boons (like country ideas)... as long as the ritual goes well
	
	- Real POLYTHEISM: embrace or adapt more gods into your existing Panteon, through a gradual process
		- Being a Greek Colony surrounded by foreign-religions, adopt some of the neighbors deities (iberian, celtic, thracian, etc)
		- First study, understand and then adopt a god from a newly conquered territory
		- Be a real Ptolemaic ruler by adding syncretized gods, after you have adopted enough Egyptian deities into your Greek Pantheon
		- Roman Religion followers keep Harmonization, but also have Cults. Their initial gods are stronger, and get weaker (even change their name) after increased interaction with neighboring religions (you remember Jupiter, Mars and Juno but not Portunus? Furrina? Pomona? kids those days...)
		- Adopted gods allow the provinces that have temples of these gods to be converted faster to your religion, at least nominally (reverts back if said deity is no longer adopted). 
		
	- Integration with other parts of the Mod
		- Popgrowth: Each temple has a special effect called "Temple Power". It gives +x commoner and upper population capacity
		- Sieges: when provinces are sacked, the money from the Temples can also be looted, depending on the religious tolerance of the attacker
		- Monuments or special modifiers are adapted: several Monuments may have a deity's temple built in, together with others (Acropolis contains, among other things, a Temple of Athena -> Can't build a second temple to the same deity). 
			
		
			
			